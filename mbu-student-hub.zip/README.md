# MBU Student Hub

A responsive static student portal inspired by the supplied university portal screenshots.

Demo login:
- Username: student
- Password: mbu123

Open `index.html` in a browser, or upload the project to GitHub Pages / Netlify / Vercel for a public URL.
